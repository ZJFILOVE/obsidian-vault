---
date: 2026-11-08
type: youtube-daily
tags: [youtube, learning, science, art]
source: ChatGPT
---

<!-- AUTO:START -->
# YouTube Daily｜2026-11-08

## 今日优先级

1. **A perspective on space: preparing for 2075**：把近期航天安排放回五十年的探索尺度，区分愿景与需要长期积累的能力。
2. **The Origins of Art Nouveau Architecture**：跟随 Paul Greenhalgh 看霍塔的四座住宅，把建筑风格放回具体空间。
3. **Cello - In Search of a Voice**：今天的 wildcard，以大提琴的遭遇连接人的身体、战争记忆与重新发声。本次链接为官方剪辑版。

## 按时间与心情选择

- **想看具体建筑**：选 Art Nouveau，从四座住宅比较同一种建筑语言的不同表达。
- **想思考长期科技问题**：选 Royal Society，围绕发射技术、重返月球与地外生命整理问题。
- **愿意慢下来**：选 The Met 的历史画讲座，或 Gresham 的大提琴故事。
- **想整理量子概念**：选 Perimeter 的 Quantum Future，把它当作 Quantum 101 系列的收束入口；遇到不熟悉的概念，再回到对应基础集。

## 1. A perspective on space: preparing for 2075

- **频道**：The Royal Society
- **主题**：未来五十年的太空探索与技术准备
- **链接**：https://www.youtube.com/watch?v=hB9JIjzIwrU

### Why watch

Sir Martin Sweeting 是皇家学会《Space: 2075》报告的共同主席。这场讲座从未来发射技术、重返月球以及寻找地外生命等问题出发，帮助我们把短期航天消息放进更长的时间尺度。NASA 于 11 月 7 日公布的月面运输和基础设施安排，可以与今天的新闻笔记一起读。观看时试着分开记录三类内容：已经有技术基础的能力、仍需要工程积累的环节，以及带有较大不确定性的远景。这样的笔记比记住某个预测年份更有用，也便于以后判断新任务究竟解决了哪一部分问题。

## 2. The Quantum Future (Where we go next)

- **频道**：Perimeter Institute for Theoretical Physics
- **主题**：Quantum 101 系列的概念整理与未来方向
- **链接**：https://www.youtube.com/watch?v=8IJdwTRSTFQ

### Why watch

Perimeter 将这支视频列为 Quantum 101 的第十集。系列由 Katie Mack 带领观众理解量子科学，前九集分别涵盖波粒二象性、量子化、不确定性、叠加、纠缠、概率、量子计算、光电效应与隧穿。它适合用来整理“听过许多名词，却不知道如何连接”的状态。建议先写出自己最想理解的一个问题，再观看这集，并用官方系列目录找到需要补上的前置概念。不要把系列简介当成对具体商业化时间表的保证。11 月 6 日已经推荐过量子力学入门，本次对主题接近作了扣分，保留的理由是它提供清楚的分集回看路径。

## 3. The Origins of Art Nouveau Architecture

- **频道**：HENI Talks
- **主题**：维克多·霍塔的住宅与新艺术建筑的起点
- **链接**：https://www.youtube.com/watch?v=k20doHDjMwo

### Why watch

艺术史学者与策展人 Paul Greenhalgh 以霍塔的建筑遗产为线索，走访 Hôtel Tassel、Hôtel Solvay、Hôtel van Eetvelde，以及建筑师自己的住宅与工作室。四座建筑让“新艺术”从一个风格名词变成可以比较的对象，也把注意力放回十九世纪末现代建筑的变化。观看时可选两座住宅，分别记录入口、楼梯、采光和装饰如何组织人的空间经验，再比较哪些特征反复出现，哪些因建筑而异。这些是观看时的观察问题，不是对未经逐段核对的画面细节作保证。HENI Talks 于 11 月 2 日出现过，本次已计入七天内同创作者的扣分；仍选择它，是为了保留具体建筑分析这一席，而不是再增加一支科技概念片。

## 4. Past Made Present: History Painting from Raphael to Leutze

- **频道**：The Met
- **主题**：历史画如何选择与组织过去
- **链接**：https://www.youtube.com/watch?v=2_rO0YNIwPA

### Why watch

艺术史学者 Kathryn Calley Galitz 在 Making History 系列的第一讲中，从拉斐尔《雅典学院》谈到大都会收藏的《华盛顿横渡特拉华河》，介绍长期被视为西方艺术重要门类的历史画。两个例子提供了一个有用的比较入口：画家如何让古典世界与国家历史成为可观看的场景？建议各选一幅作品暂停观察，先自己辨认画面的中心、人物动作与视线方向，再听讲者展开说明。把“我看到什么”和“我因此如何理解历史”分开记录，可以帮助我们更谨慎地阅读那些看似直接呈现过去的图像。

## 5. Cello - In Search of a Voice

- **频道**：Gresham College
- **主题**：大提琴、身体、失语与记忆
- **版本**：官方页面当前嵌入的剪辑版，不是原推荐的直播录像
- **链接**：https://www.youtube.com/watch?v=LI53uFBXj4I

### Why watch

这是今天的 wildcard。Kate Kennedy 从自己受伤后与大提琴关系的变化出发，追索乐器与演奏者的共同经历。官方讲稿包括海难后被重建的乐器、集中营中的生存、失散乐器与家人的重逢，以及成为蜂巢的大提琴。这些故事把声音放回身体、材料、修复和记忆之中。观看时可以选一个案例，问：如果只保存乐谱或人物传记，会遗漏什么？乐器留下的损伤、修补与使用痕迹，又能补充什么？Gresham 于 11 月 7 日出现过，已计入同创作者扣分；保留它的理由是这种以物件追索个人经历的方法与今天其他四支明显不同。

## 勾选观看

- [ ] A perspective on space: preparing for 2075
- [ ] The Quantum Future (Where we go next)
- [ ] The Origins of Art Nouveau Architecture
- [ ] Past Made Present: History Painting from Raphael to Leutze
- [ ] Cello - In Search of a Voice（官方剪辑版）

## Notes

本页在恢复过程中重新核验并调整了两处选择：原 Villa Savoye 条目改为 HENI 的新艺术建筑影片；Cello 改用发布方当前嵌入的剪辑版，未将它与原直播录像视作同一条视频链接。原先的选择记录仍保留，不会因此被当成从未推荐过。

本次核验范围为发布方官方页面上的标题、创作者归属、精确 YouTube 链接或嵌入 ID，以及内容说明；Perimeter 的内容说明以官方系列目录为依据。五支视频均未进行全片播放测试，也未验证登录、地区或设备条件下的播放可用性。候选比较与这些核验均为恢复时重新完成，不代表原运行时的浏览记录。
<!-- AUTO:END -->
